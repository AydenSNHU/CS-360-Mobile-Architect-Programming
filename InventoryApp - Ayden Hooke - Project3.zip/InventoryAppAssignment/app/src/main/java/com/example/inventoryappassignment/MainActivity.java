package com.example.inventoryappassignment;

import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryappassignment.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    LinearLayout layoutList;
    Button buttonAdd;
    TextView itemQuantity;


    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);
       /* binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        layoutList = findViewById(R.id.warehouseInventory);
        buttonAdd = findViewById(R.id.addItem);
        itemQuantity = findViewById(R.id.itemQuantity);

        buttonAdd.setOnClickListener(this);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public void onClick(View view) {
        addView();
    }

    private void addView() {

        View itemView = getLayoutInflater().inflate(R.layout.rowadditem, null,  false);

        EditText editText = (EditText)itemView.findViewById(R.id.editItemName);
        ImageView imageClose = (ImageView)itemView.findViewById(R.id.removeItem);
        ImageView increaseNumber = (ImageView)itemView.findViewById(R.id.increaseQuantity);
        ImageView decreaseNumber = (ImageView)itemView.findViewById(R.id.decreaseQuantity);


        imageClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeView(itemView);
            }

        });

        increaseNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                increaseQuantity(itemView);
            }
        });

        decreaseNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decreaseQuantity(itemView);
            }
        });

        layoutList.addView(itemView);
    }

    private void removeView(View view) {

        layoutList.removeView(view);
    }

    public void decreaseQuantity(View view){
        /*int current = itemQuantity.getText().charAt(itemQuantity.length()-1);
        current += current;*/
        //String newValue = "#: ";
     //   itemQuantity.setText("newValue");
    }

    public void increaseQuantity(View view){
        /*int current = itemQuantity.getText().charAt(itemQuantity.length()-1);
        current += current;
        String newValue = "#: " + current;*/
     /*   itemQuantity.setText("newValue");*/
    }
}